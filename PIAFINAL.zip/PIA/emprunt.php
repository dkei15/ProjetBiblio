<?php
session_start();

//connect to database

	$db=mysqli_connect("localhost","root","","biblio");




?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Ajout ou Supprimer</title>
		<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE">
		<META NAME="Publisher" CONTENT="Khadija MOUSTAINE">
		<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
		<META NAME="Language" CONTENT="fr">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="css/style.css" type="text/css">
		<link rel="stylesheet" href="css/connexion.css" type="text/css">

	</head>

	<body>
		<div id="page">
			<div id="header">
				<a href="index.php" id="logo"><img src="images/logo.jpg" width= "200" height = "150"  alt="LOGO"></a>

				<ul id="navigation">
				<li class="selected">
					<a href="index.php" title="Home"></a>
				</li>
				<li>
					<a href="desinscrire.php">Desinscription</a>
				</li>
				<li>
					<a href="ajoutSuppr.php">Oeuvres</a>
				</li>
				<li>
					<a href="commande-admin.php">Commande</a>
				</li>
				<li>
					<a href="ajoutEvenement.php">Evenement</a>
				</li>
				<li>
					<a href="emprunt.php">Emprunt</a>
				</li>
			</ul>
			</div>
			<div id="contents">
				<div class="background">
					<div id="centre">
					<?php
				if(!isset($_SESSION['adminame'])) { echo "" ;  }// A MODIFEIR PAR ADMINAME
				else { echo "<a class='deconnexion' href='deconnexion.php'>Deconnexion</a>"; }
				?>
						<header>
							<h1 class ="h1">Emprunt/Retour de livre</h1>
						</header>
						<?php

						if(isset ($_SESSION['adminame'])){ // A MODIFEIR PAR ADMINAME
							if(isset($_GET['finish'])){
								$_SESSION['IdentifiantTmp']=$_GET['Identif'];
								header('Location: emprunt.php');
								exit(0);
							}
						echo'	<div id="ajouteOeuvre" align="center">';
						if(isset($_GET['Identif'])){
							$resultat1 ="SELECT COUNT(*) as Nombre FROM adherent WHERE IdAdherent=".$_GET['Identif']."";
							$result=mysqli_query($db,$resultat1);
							$tab=mysqli_fetch_array($result, MYSQLI_ASSOC);
							if($tab['Nombre']>0){
								$_SESSION['Identif']=$_GET['Identif'];
								header("Location: emprunt_real.php" );
								exit(0);
							}else{
								echo"Le numéro de l\'adhérent entré ne correspond à aucun adhérent de la bibliothèque";
								unset($_GET['Identif']);
							}
						}


							echo'	<form method="get" action="emprunt.php" >
									<fieldset >
										<table>

										<tr>
										 <td width = "200px" class="text" ><b>Numero d\'adherent :</b> </td>
										 <td><input type="text" name="Identif"  autocomplete="off" class="textInput" ></td>
									 </tr>
                    </table>
									</fieldset>
									</br>
									<input  type="submit" name="emprunt"  class="login" align="center" value="Poursuivre"/>
									<input type="reset" value="Annuler" class="login" />
									</br></br>
								</form>

					</div>';



}


				?>
				</div>

				<?php if(!isset($_SESSION['adminame'])){ // A MODIFEIR PAR ADMINAME
					echo "<div id='connexion' align='center'>
								<form method='post' action='connexion-admin.php'>
									<fieldset>
										<table>
											<legend>Informations Personnelles</legend>
											<tr>
												<td width = '150px' class='text' ><b>Indentifiant :</b></td>
												<td><input type='text' name='username' class='textInput' width = '150px'></td>
											</tr>
											<tr>
												<td width = '150px' class='text' ><b>Mot de passe :</b></td>
												<td><input type='password' name='password' class='textInput' width = '150px'></td>
											</tr>
										</table>
									</fieldset>
									</br>
									<input  type='submit' name='admin_btn'  class='login' align='center' value='Se connecter'/>
									<input type='reset' value='Annuler' class='login' />
									</br></br>
								</form>
				</div>";} ?>
			</div>
		</div>
	</body>
</html>
