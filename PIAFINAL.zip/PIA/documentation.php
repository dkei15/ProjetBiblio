<?php
session_start();
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>connexion</title>
	<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE">
	<META NAME="Publisher" CONTENT="Khadija MOUSTAINE">
	<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
	<META NAME="Language" CONTENT="fr">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/connexion.css" type="text/css">
</head>
<body>
	<div id="page">
		<div id="header">
			<?php
				if(!isset($_SESSION['username']))
				{
					echo "<a class='contact' href='inscription.php'>S'inscrire</a>" ;
				}
				else
				{
					echo "";
				}
			?>
			<?php
				if(!isset($_SESSION['username']))
				{
					echo "<a class='connexion-index' href='connexion.php'>Connexion</a>" ;
				}
				else
				{
					echo "<a class='Deconnexion-index' href='deconnexion.php'>Deconnexion</a>";
				}
			?>
			<a href="index.php" id="logo"><img src="images/logo.jpg" widtht= "250" height = "150"  alt="LOGO"> </a>
			<ul id="navigation">
				<li class="selected">
					<a href="index.php" title="Home"></a>
				</li>
				<li>
					<a href="espace.php">Espace personnel</a>
				</li>
				<li>
					<a href="documentation.php">Documentation</a>
				</li>
				<li>
					<a href="service.php">Service</a>
				</li>
				<li>
					<a href="evenement.php">Evenement</a>
				</li>
				<li class="last-child">
					<a href="contact.php">Contact nous</a>
				</li>
			</ul>
		</div>
			<div id="contents">
			<div class="background" align="center">
				<div id="centre" align="center">
					<header>
						<h1 class =h1>Rechercher</h1>
					</header>
					<form class="form-search" name="search_form" method="post"  action="documentationSearch.php">

					<div align="center">
  	         <input type="text" value="" class ="login1" placeholder="Nom d'une oeuvre..." name="s"  />
  	         <input  type="submit" name="submit" class="login" value="Trouver"/>
            </form>
					</div>
				


	</div>
</body>
</html>
