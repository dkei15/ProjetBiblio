<?php session_start() ?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Contactez-Nous</title>
		<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE"> 
		<META NAME="Publisher" CONTENT="Khadija MOUSTAINE"> 
		<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
		<META NAME="Language" CONTENT="fr">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="css/style.css" type="text/css">
		<link rel="stylesheet" href="css/connexion.css" type="text/css">
	</head>
	
	<body>
		<div id="page">	
			<div id="header">
				<?php 
				if(!isset($_SESSION['username'])) 
				{
					echo "<a class='contact' href='inscription.php'>S'inscrire</a>" ;  
				} 
				else
				{
					echo ""; 
				} 
			?>
			<?php 
				if(!isset($_SESSION['username'])) 
				{
					echo "<a class='connexion-index' href='connexion.php'>Connexion</a>" ;  
				} 
				else 
				{
					echo "<a class='Deconnexion-index' href='deconnexion.php'>Deconnexion</a>"; 
				}
			?> 
				<a href="index.php" id="logo"><img src="images/logo.jpg" width= "200" height = "150"  alt="LOGO"></a>
				
				<ul id="navigation">
					<li class="selected">
						<a href="index.php" title="Home"></a>
					</li>
					<li>
						<a href="espace.php">Espace personnel</a>
					</li>
					<li>
						<a href="documentation.php">Documentation</a>
					</li>
					<li>
						<a href="service.php">Service</a>
					</li>
					<li>
						<a href="evenement.php">Evenement</a>
					</li>
					<li class="last-child">
						<a href="contact.php">Contact nous</a>
					</li>                         
				</ul>
			</div>
			<div id="contents">
				<div class="background">
					<div id="centre">
						<header>
							<h1 class ="h1">Contactez-Nous</h1>
								<?php
									if(isset($_SESSION['message']))
									{
										 echo "<div username='error_msg'>".$_SESSION['message']."</div>";
										 unset($_SESSION['message']);
									}
								?>
								
							
						</header>
						<div id="news">
							<ul>
								<li>
									<p>
										<em><u>Vous pouvez nous joindre :</u></em>
											-par téléphone, au 04 91 55 90 00</br>
											-par fax, au 04 91 55 23 44</br>
										Pour prolonger vos documents par téléphone : 04 91 55 91 55</br>
										
										<em><u>Vous ne trouvez pas un renseignement concernant le fonctionnement de la bibliothèque 
										sur le site et souhaitez entrer en contact avec nous ? Ecrivez-nous :</u></em>
 
										Nous prenons connaissance et répondons à vos messages du mardi au samedi.
									</p>
								</li>
							</ul>
						</div>
						
						<div id="connexion" align="center">
								<form method="post" action="contact.php" >
									<fieldset >
										<table>
											<legend> Contactez-nous</legend>
	
											 <tr>
												   <td width = "150px" class="text"><b>Indetifiant :</b> </td>
												   <td><input type="text" name="username" class="textInput"></td>
											 </tr>
											 <tr>
												<td width = "150px" class="text" ><b>Email :</b> </td>
												<td><input type="email" name="email" class="textInput" ></td>
											</tr>
											<tr>
											   <td width = "150px" class="text" ><b>Objet :</b></td>
											   <td><input type="text" name="nom" class="textInput"></td>
											</tr>
											<tr>
												<td width = "150px" class="text"><b>Message:</b></b></td>
												<td><textarea class="textInput" name="message"  id="Message"></textarea></td>
											</tr>
										</table>
									</fieldset>
									</br>
									<input  type="submit" name="contat_btn"  class="login" align="center" value="Envoyer"/>
									<input type="reset" value="Annuler" class="login" />
									</br></br>
								</form>
								
								

				
					</div>
				</div>
					
			</div>
		</div>
	</body>
</html>