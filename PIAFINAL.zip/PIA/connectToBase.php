<?php
//connect to database

	$db=mysqli_connect("localhost","root","","biblio");

$mysqli = new mysqli("localhost","root","","biblio");
if ($mysqli->connect_errno) {
		echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
	if(isset($_SESSION['message']))
	{
		 echo "<div username='error_msg'>".$_SESSION['message']."</div>";
		 unset($_SESSION['message']);
	}

?>  
