<?php
	session_start();
	//connect to database
	$db=mysqli_connect("localhost","root","","biblio");
	$count = 1;
	if(isset($_SESSION['count'])){
		$count = $_SESSION['count'];
		unset ($_SESSION['count']);
	}
	for($j=1;$j<=$count;$j++){
		$ok = "btn_suppr".$j;
		$ok1 = "cote".$j;
		if(isset($_POST[$ok])){
			$isbn = mysqli_real_escape_string($db,$_POST[$ok1]);
			$quer = "DELETE FROM commande WHERE cote = '$isbn'";
			mysqli_query($db,$quer);
			break;
		}
		
	}
	$i=0;
	$name='';
	$query="SELECT cote, titreOeuvre, Commentaire, idAdherent FROM commande ";
	
	
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Ajout ou Supprimer</title>
		<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE">
		<META NAME="Publisher" CONTENT="Khadija MOUSTAINE">
		<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
		<META NAME="Language" CONTENT="fr">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="css/style.css" type="text/css">
		<link rel="stylesheet" href="css/connexion.css" type="text/css">
	</head>

	<body>
		<div id="page">
			<div id="header">
					<?php 
				if(!isset($_SESSION['adminame'])) { }
				else { 
					echo "<a class='deconnexion-index' href='deconnexion-admin.php'>Deconnexion</a>"; 
					} 
				?>
				<a href="index.php" id="logo"><img src="images/logo.jpg" width= "250" height = "150"  alt="LOGO"></a>

				<ul id="navigation">
			<li class="selected">
				<a href="index.php" title="Home"></a>
			</li>
			<li>
				<a href="desinscrire.php">Desinscription</a>
			</li>
			<li>
				<a href="ajoutSuppr.php">Oeuvres</a>
			</li>
			<li>
				<a href="commande-admin.php">Commande</a>
			</li>
			<li>
				<a href="ajoutEvenement.php">Evenement</a>
			</li>
			<li>
				<a href="emprunt.php">Emprunt</a>
			</li>
		</ul>
			</div>
			<div id="contents">
				<div class="background">
					<div id="centre">
					<header>
						<h1>Commandes des Adhérents</h1>
						<?php
							if(isset($_SESSION['message']))
							{
								echo "<div username='error_msg'>".$_SESSION['message']."</div>";
								unset($_SESSION['message']);
							}
						?>		
					</header>
					<?php  
						if(isset ($_SESSION['adminame']))
						{
					   
							 if ($result = mysqli_query($db, $query)) {

								echo '<table border="2px"><tr><td>ISBN</td><td>Titre de l\'Oeuvre</td><td>Commentaire</td><td>Demandeur de la commande</td>';
								
									while ($row = mysqli_fetch_assoc($result)) {
										 $i=$i+1;
										 $name=''.$i; 
										 $idAdherent = $row['idAdherent'];
										 $sql = "SELECT Adprenom,AdNom FROM adherent JOIN commande ON adherent.IdAdherent = '$idAdherent'";
										
										 if($resultad = mysqli_query($db,$sql)){
											$rowad = mysqli_fetch_assoc($resultad);
										 }
										
										 echo '<div>
													  <form method="post" action="commande-admin.php">
															  <tr>
																   <td><input type="text" class="textInputt" value="'.$row['cote'].'" name="cote'.$name.'" ></input></td>
																   <td><input type="text" class="textInputt" value="'.$row['titreOeuvre'].'" disabled></input></td>
																   <td><textarea type="text" class="textInputt" disabled>'.$row['Commentaire'].'</textarea></td>
																   <td><input type="text" class="textInputt" value ="'.$rowad['AdNom'].' '.$rowad['Adprenom'].'"  disabled></input></td>
																   <td><input type="submit" value="Supprimer" class= "login2" name="btn_suppr'.$name.'"></input></td>
															  </tr>
													 </form>
											   </div>';
										$_SESSION['count'] = $i;	 
									}
									
								echo '</tr></table>';
							}
							
						}
						 
						
						?>
						</div>
						<?php 
							if(!isset($_SESSION['adminame']))
							{ 
								echo "<div id='connexion' align='center'>
									<form method='post' action='connexion-admin.php'>
										<fieldset>
											<table>
												<legend>Informations Personnelles</legend>
												<tr>
													<td width = '150px' height='40px' class='text' ><b>Indentifiant :</b></td>
													<td><input type='text' name='username' class='textInput' width = '150px'></td>
												</tr>
												<tr>
													<td width = '150px' height='40px' class='text' ><b>Mot de passe :</b></td>
													<td><input type='password' name='password' class='textInput' width = '150px'></td>
												</tr>
											</table>
										</fieldset>
										</br>
										<input  type='submit' name='connexion_btn'  class='login' align='center' value='Se connecter'/>
										<input type='reset' value='Annuler' class='login' />
										</br>
										</br>
									</form>
								</div>";} 
							?>
						</div>
					</div>
					<div id="footer">
						<div class="connect">
							<?php
								if(isset($_SESSION['username'])) 
								{
									$username =  $_SESSION['username'] ;    
									echo " Connecté en tant que $username " ; 
								}  
							?>
				
						</div>
						<p>Site crÃ©e par Khadija MOUSTAINE, Alex TAYLOR, Anaud BROSSE </p>			
					</div>
				</div>
			</div>
		</div>
	</body>
</html>