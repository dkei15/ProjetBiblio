<?php
  if(!isset($_SESSION['username']))
  {
    echo "<div id='connexion' align='center'>
      <form method='post' action='connexion.php'>
        <fieldset>
          <table>
            <legend>Informations Personnelles</legend>
            <tr>
              <td width = '150px' height='40px' class='text' ><b>Identifiant :</b></td>
              <td><input type='text' name='username' class='textInput' width = '150px'></td>
            </tr>
            <tr>
              <td width = '150px' height='40px' class='text' ><b>Mot de passe :</b></td>
              <td><input type='password' name='password' class='textInput' width = '150px'></td>
            </tr>
          </table>
        </fieldset>
        </br>
        <input  type='submit' name='connexion_btn'  class='login' align='center' value='Se connecter'/>
        <input type='reset' value='Annuler' class='login' />
        </br>
        </br>
      </form>
    </div>";}
  ?>
</div>
</div>
