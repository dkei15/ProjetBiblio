<?php session_start() ?>
<html>
<head>
	<meta charset="UTF-8">
	<title>Gestion du bibliothéque</title>
	<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Publisher" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
	<META NAME="Language" CONTENT="fr">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
	<div id="page">	
		<div id="header">

			<?php 
				if(!isset($_SESSION['username'])) { echo "<a class='contact-index' href='inscription.php'>S'inscrire</a>" ;  } 
				else { echo ""; } 
			?>  
			
			<?php 
				if(!isset($_SESSION['username'])) { echo "<a class='connexion' href='connexion.php'>Connexion</a>" ;  } 
				else { echo "<a class='deconnexion-index' href='deconnexion.php'>Deconnexion</a>"; } 
				?> 
			
			<a href="index.php" id="logo"><img src="images/logo.jpg" width= "200" height = "150" alt="LOGO"></a>
			
			<ul id="navigation">
				<li class="selected">
					<a href="index.php" title="Home"></a>
				</li>
				<li>
					<a href="espace.php">Espace personnel</a>
				</li>
				<li>
					<a href="documentation.php">Documentation</a>
				</li>
				<li>
					<a href="service.php">Service</a>
				</li>
				<li>
					<a href="evenement.php">Evenement</a>
				</li>
				<li class="last-child">
					<a href="contact.php">Contact nous</a>
				</li>
			</ul>
			
			<div id="adbox">
				<img src="images/biblio.jpg" alt="Img" height="496" width="958">
				<div class="details">
					<h1>bibliothèque universitaire de marseille </h1>
				</div>
			</div>
		</div>
		
		<div id="contents">
				<div id="main">
					<h2>Horaires et accès </h2>
					<h3>Accueil, renseignements, prêt ou retour des documents</h3>
					<p>	
						- Du Lundi au Vendredi de 9h à 19h.</br>
						- Samedi de 9h à 12h. 
					</p>

					<h3>Aller à la Bibliothèque de Marseille : </h3>
					<p>
						Bus : <a href="http://www.rtm.fr/"/>http://www.rtm.fr/</a> </br>
						---
					</p>
		
					<h2>Infos pratiques </h2>
						<p>
							Le réseau de la bibliothèque de Marseille vous propose de multiples activités : </br>
							
							- Se cultiver,</br>
							- S'informer,</br>
							- Se former,</br>
							- Travailler,</br>
							- Se divertir,</br>
							
							DÉCOUVREZ !</br>
						</p>
					
					<h2>Inscription et tarifs </h2>
						<p>							
							- L’entrée à la bibliothèque et la consultation sur place sont libres et gratuites.</br> 
							- Une inscription annuelle permet d’emprunter des documents et d’accéder aux offres d’autoformation.</br>
							- L’abonnement est valable un an à compter de la date d’inscription.</br>
							- S’inscrire à la bibliothèque implique l’acceptation du règlement intérieur.</br>
						</p>
					
				</div>	
		</div>
		
		<div id="footer">
			<div class="connect">
					<?php
						if(isset($_SESSION['username'])) { $username =  $_SESSION['username'] ;    
						echo " Connecté en tant que <a href=\"espace.php\" target\"contenu\">$username</a> " ;  }  
					?>
				
			</div>
			<p>Site crée par Khadija MOUSTAINE, Alex TAYLOR, Anaud BROSSE </p>			
		</div>	
	</div>
</body>
</html>