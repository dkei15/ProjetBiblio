<?php
session_start();

//connect to database
	
	$db=mysqli_connect("localhost","root","","biblio");
	
	if(isset($_GET['contat_btn'])){
		if (empty($_GET['ISBN']) || empty($_GET['TitreOeuvre']) || empty($_GET['typeOeuvre'])){
			echo 'remplissez tous les champs ! '; 
		}else{
			
			$isbn =  mysqli_real_escape_string($db,$_GET['ISBN']);
			$titreoeuvre =  mysqli_real_escape_string($db,$_GET['TitreOeuvre']);
			$typeoeuvre =  mysqli_real_escape_string($db,$_GET['typeOeuvre']);
			$nomauteur = mysqli_real_escape_string($db,$_GET['nomAuteur']);
			$resultat1 = "SELECT idAuteur FROM auteur WHERE nomAuteur='$nomauteur'";
			$result = mysqli_query($db,$resultat1);
			$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
			$idauteur = $row['idAuteur'];
			if((mysqli_num_rows($result)== 0)){
				$resultat = "INSERT INTO auteur(nomAuteur) VALUES('$nomauteur')";
				mysqli_query($db,$resultat);
			}
				$resultat2 = "INSERT INTO oeuvre(cote,titre,TypeOeuvre,IdAuteur) VALUES ('$isbn','$titreoeuvre','$typeoeuvre','$idauteur')" ;
				mysqli_query($db,$resultat2);
				echo 'Oeuvre et Auteur ajouté avec succès';
		}
		
	}
	
	if(isset($_GET['suppr_btn'])){
		$isbn =  mysqli_real_escape_string($db,$_GET['supprOeuvre']);
		$sql = "DELETE FROM oeuvre WHERE cote = '$isbn'";
		mysqli_query($db,$sql);
		echo 'oueuvre supprimé avec succès';
	}
	
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Ajout ou Supprimer</title>
		<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE">
		<META NAME="Publisher" CONTENT="Khadija MOUSTAINE">
		<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
		<META NAME="Language" CONTENT="fr">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="css/style.css" type="text/css">
		<link rel="stylesheet" href="css/connexion.css" type="text/css">
		<!-- <script type='text/javascript'>
				function addFields(){
					// Number of inputs to create
					var number = document.getElementById("auteur").value;
					// Container <div> where dynamic content will be placed
					var container = document.getElementById("container");
					// Clear previous contents of the container
					while (container.hasChildNodes()) {
						container.removeChild(container.lastChild);
					}
					for (i=0;i<number;i++){
						// Append a node with a random text
						//container.appendChild(document.createTextNode("Auteur " + (i+1)));
						// Create an <input> element, set its type and name attributes
						var input = document.createElement("input");
						input.type = "text";
						input.name = "Auteur" + i;
						container.appendChild(input);
						// Append a line break 
						container.appendChild(document.createElement("br"));
					}
				}
		</script>-->
	</head>

	<body>
		<div id="page">
			<div id="header">
				<a href="inscription.php" class="contact" >S'inscrire</a>
				<a href="index.php" id="logo"><img src="images/logo.jpg" width= "250" height = "150"  alt="LOGO"></a>

				<ul id="navigation">
					<li class="selected">
						<a href="index.php" title="Home"></a>
					</li>
					<li>
						<a href="espace.php">Espace personnel</a>
					</li>
					<li>
						<a href="documentation.php">Gestion des oeuvres</a>
					</li>
					<li>
						<a href="service.php">Service</a>
					</li>
					<li>
						<a href="evenement.php">Evenement</a>
					</li>
					<li class="last-child">
						<a href="contact.php">Contact nous</a>
					</li>
				</ul>
			</div>
			<div id="contents">
				<div class="background">
					<div id="centre">
						<header>
							<h1 class ="h1">Gestion des oeuvres</h1>


						</header>

			

						<div id="ajouteOeuvre" align="center">
								<form method="get" action="ajoutSuppr.php" >
									<fieldset >
										<table>
											<legend> Ajouter une oeuvre</legend>

											<tr>
													<td width = "150px" class="text"><b>ISBN :</b> </td>
													<td><input type="text" name="ISBN" autocomplete="off"  class="textInput"></td>
											</tr>
											 <tr>
												<td width = "150px" class="text" ><b>Titre de l'oeuvre :</b> </td>
												<td><input type="text" name="TitreOeuvre" autocomplete="off" class="textInput" ></td>
											</tr>
											<tr>
												<td width = "150px" class="text"><b>Type de l'oeuvre :</b> </td>
												<td>
													<select name="typeOeuvre" class="textInput">
														<option value="Vide"></<option>
														<option value="Magazine">Magazine</<option>
														<option value="DVD">DVD</<option>
														<option value="Livre">Livre</<option>
														<option value="Periode">Périodique</<option>
														<option value="Partitions">Partitions</<option>
													</select>
											</tr>
											
												<tr>
												   <td width = "150px" class="text" ><b>Nombre Auteur</b></td>
												   <td><input type="text" name="nomAuteur" class="textInput"></td>
												   <!--<td><input type="text" id="auteur" name="auteur" value=""></td>-->
												   <!--<td><a href="#"  id="filldetails" onclick="addFields()">Ajouter un auteur</a></td>-->
												</tr>
											    <!--<tr>
													<td width = "150px" class="text"><b>Noms Auteur </b></td>
													<td id="container"></td>
												</tr>-->
											<tr>
												<td width = "150px" class="text"><b>Date de parution:</b></b></td>
												<td><input type="date" name="dateParu"  class="textInput" value="1989-12-22"></td>
											</tr>
											<tr>
												<td width = "150px" class="text"><b>Prix d'achat:</b></b></td>
												<td><input type="number" name="prixAchat"  class="textInput"></td>
											</tr>
											<tr>
												<td width = "150px" class="text"><b>Domaine:</b></b></td>
												<td>
													<select name="domaine" class="textInput">
														<option value="Vide"></<option>
														<option value="Rom">Roman</<option>
														<option value="Socio">Sociologie</<option>
														<option value="Art">Art</<option>
														<option value="Sciences">Sciences</<option>
														<option value="Culture">Culture</<option>
													</select>
												</td>
											</tr>

										</table>
									</fieldset>
									</br>
									<input  type="submit" name="contat_btn"  class="login" align="center" value="Ajouter"/>
									<input type="reset" value="Annuler" class="login" />
									</br></br>
								</form>
					</div>




					<div  align="center">
							<form method="get" action="ajoutSuppr.php" >
								<fieldset >
									<table>
										<legend> Supprimer une oeuvre</legend>

										 <tr>
												 <td width = "150px" class="text"><b>ISBN :</b> </td>
												 <td><input type="text" name="supprOeuvre" class="textInput"></td>
										 </tr>

									</table>
								</fieldset>
								<input  type="submit" name="suppr_btn"  class="login" align="right" value="Supprimer"/>
								</br>
								</br></br>
							</form>
				</div>
				</div>
			</div>
		</div>
	</body>
</html>