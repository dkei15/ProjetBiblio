Import seed data:
-----------------
- Create a mysql database called "clinkpm"
- Import seed_data.sql.qz into this database
- update "req_connect.php" with db credentials
