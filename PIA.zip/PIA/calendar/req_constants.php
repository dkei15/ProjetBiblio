<?php

define("USER_TABLE", "users");
define("LEAVE_PLAN_TABLE", "leave_plans");
define("PUBLIC_HOLIDAYS_TABLE", "public_holidays");
define("RELEASES_TABLE", "releases");

$reqAsterix = '<font color=red size=4><b>*</b></font>';
$reqKey = $reqAsterix.' denotes required field<br/>';


?>