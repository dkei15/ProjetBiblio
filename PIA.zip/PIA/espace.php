<?php
session_start();

//connect to database

	$db=mysqli_connect("localhost","root","","biblio");


?>
<html>
<head>
	<meta charset="UTF-8">
	<title>Gestion du bibliothéque</title>
	<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Publisher" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
	<META NAME="Language" CONTENT="fr">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	
</head>
<body>
	<div id="page">	
		<div id="header">
			
			
			<?php if(!isset($_SESSION['username'])) { echo "<a class='contact-index' href='inscription.php'>S'inscrire</a>" ;  } 
			else { echo ""; } ?>  
			
			<?php 
				if(!isset($_SESSION['username'])) { echo "<a class='connexion' href='connexion.php'>Connexion</a>" ;  } 
				else { echo "<a class='connexion' href='deconnexion.php'>Deconnexion</a>"; } 
				?> 
			
			<a href="index.php" id="logo"><img src="images/logo.jpg" width= "200" height = "150" alt="LOGO"></a>
			
			<ul id="navigation">
				<li class="selected">
					<a href="index.php" title="Home"></a>
				</li>
				<li>
					<a href="espace.php">Espace personnel</a>
				</li>
				<li>
					<a href="documentation.php">Documentation</a>
				</li>
				<li>
					<a href="service.php">Service</a>
				</li>
				<li>
					<a href="evenement.php">Evenement</a>
				</li>
				<li class="last-child">
					<a href="contact.php">Contact nous</a>
				</li>
			</ul>
			
		
		</div>
		<div id="contents">
			<div class="background">
				<div id="centre">
					<header>
						<h1 class ="h1">Bienvenue</h1>
					</header>
				
					<?php
						if(isset($_SESSION['message']))
						{
							 echo "<div username='error_msg'>".$_SESSION['message']."</div>";
							 unset($_SESSION['message']);
						}
					?>
					<?php  
								
								

					if(isset ($_SESSION['username'])){
						$date=date_create($_SESSION['dateNaissance']);
						 echo '<div>
								<table>
									<tr>
										<th>
										<h4>Bonjour ! '.$_SESSION['nom'].'</h4>
										</th>
									</tr>
									<tr>
										<td>
											<p>Indentifiant </p>
										</td>
										<td>
											<th><p>'.$_SESSION['username'].'</p></th>
										</td> 
									</tr>
									<tr>
										<td>
											<p>NOM </p>
										</td>
										<td>
											<th><p>'.$_SESSION['nom'].'</p></th>
										</td> 
									</tr>
									<tr>
										<td>
											<p>PRENOM </p>
										</td>
										<td>
											<th><p>'.$_SESSION['prenom'].'</p></th>
										</td> 
									</tr>

									<tr>
										<td>
											<p>COURRIER </p>
										</td>
										<td>
											<th><p>'.$_SESSION['mail'].'</p></th> 
										</td>
									</tr>
									
									<tr>
										<td>
											<p>ADRESSE </p>
										</td>
										<td>
											<th><p>'.$_SESSION['adresse'].'</p> </th>
										</td>
									</tr>
									
									<tr>
										<td>
											<p>TELEPHONE </p>
										</td>
										<td>
											<th><p>'.$_SESSION['tel'].'</p></th>
										</td>
									</tr>
									<tr>
										<td>
											 <p>NEE LE </p>
										</td>
										<td>
											<th><p>'.date_format($date,"d/m/Y").'</p></th>
										</td>
									</tr>
									
								</table>
							  </div>
							  <form action = "modifInfos.php">
									<button>Modifier vos informations</button>
							  </form>';
					}?>
				</div>
				<?php if(!isset($_SESSION['username'])){ 
					echo "<div id='connexion' align='center'>
								<form method='post' action='connexion.php'>
									<fieldset>
										<table>
											<legend>Informations Personnelles</legend>
											<tr>
												<td width = '150px' class='text' ><b>Indentifiant :</b></td>
												<td><input type='text' name='username' class='textInput' width = '150px'></td>
											</tr>
											<tr>
												<td width = '150px' class='text' ><b>Mot de passe :</b></td>
												<td><input type='password' name='password' class='textInput' width = '150px'></td>
											</tr>
										</table>
									</fieldset>
									</br>
									<input  type='submit' name='connexion_btn'  class='login' align='center' value='Se connecter'/>
									<input type='reset' value='Annuler' class='login' />
									</br></br>
								</form>
				</div>";} ?>
				

			</div>
		</div>
</body>

</html>