<?php
session_start();
//connect to database
$db=mysqli_connect("localhost","root","","biblio");
if(isset($_POST['connexion_btn']))
{
    $username=mysqli_real_escape_string($db,$_POST['username']);
    $password=mysqli_real_escape_string($db,$_POST['password']);
    $passwordCrypt = md5($password);
    $sql="SELECT username, MotDePass FROM adherent WHERE username = '$username' AND MotDePass = '$passwordCrypt'";
	$result = mysqli_query($db,$sql);
	$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
	if($username != "" && $password != ""){
	
			if(mysqli_num_rows($result)> 0)
			{
				$_SESSION['message']="Vous êtes maintenant connecté";
				$_SESSION['username']=$username;
				header("location:index.php");
			}
		   else
		   {
						$_SESSION['message']="Nom d'utilisateur ou mot de passe est incorrect ";
			}
	}else{
		$_SESSION['message']="Veuillez remplir les 2 champs! ";
	}
}
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>connexion</title>
		<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE"> 
		<META NAME="Publisher" CONTENT="Khadija MOUSTAINE"> 
		<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
		<META NAME="Language" CONTENT="fr">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="css/style.css" type="text/css">
		<link rel="stylesheet" href="css/connexion.css" type="text/css">
	</head>
	<body>
		<div id="page">	
			<div id="header">	
				<a href="inscription.php" class="contact" >S'inscrire</a>
				<a href="index.php" id="logo"><img src="images/logo.jpg" width= "250" height = "150"  alt="LOGO"> </a>
				
				<ul id="navigation">
					<li class="selected">
						<a href="index.php" title="Home"></a>
					</li>
					<li>
						<a href="espace.php">Espace personnel</a>
					</li>
					<li>
						<a href="documentation.php">Documentation</a>
					</li>
					<li>
						<a href="service.php">Service</a>
					</li>
					<li>
						<a href="evenement.php">Evenement</a>
					</li>
					<li class="last-child">
						<a href="contact.php">Contact nous</a>
					</li>
				</ul>
			</div>
			
			<div id="contents">
				<div class="background">
					<div id="centre">
						<header>
							<h1 class ="h1">Service d'authentification</h1>		
							<?php
								if(isset($_SESSION['message']))
								{
									 echo "<div username='error_msg'>".$_SESSION['message']."</div>";
									 unset($_SESSION['message']);
								}
							?>
							
							<?php 
							
								if(!isset($_SESSION['username'])) { echo "<a class='connexion' href='connexion.php'>Connexion</a>" ;  } 
								else { echo "<a class='connexion' href='deconnexion.php'>Deconnexion</a>"; }
							?>  
						</header>
						<div id="connexion" align="center">
							<form method="post" action="connexion.php">
								<fieldset>
									<legend>Identifiez-vous pour poursuivre</legend>
									<section class="row">
										<label for="username" class ="text"width = "150px"><b>Indentifiant  :</b> </label>
										<input type="text" name="username" class="textInput" width = "150px">
									</section>
									<section class="row">
										<label for="password" class ="text"width = "150px"><b>Mot de passe  :</b> </label>
										<input type="password" name="password" class="textInput" width = "150px">
									</section>
									<section class="row-btn">
									</section>
								</fieldset>
								</br>
								<input  type="submit" name="connexion_btn"  class="login" align="center" value="Se connecter"/>
							</form>
						</div>
					</div>
					<div id="inscription">
						<p>
							<a href ="inscription.php"><i class="i">vous êtes pas inscrit?<i></a>
						</p>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>