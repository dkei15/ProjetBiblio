<?php
session_start();
//connect to database
$db=mysqli_connect("localhost","root","","biblio");
if(isset($_POST['inscription_btn']))
{
    $username=mysqli_real_escape_string($db,$_POST['username']);
    $email=mysqli_real_escape_string($db,$_POST['email']);
    $password=mysqli_real_escape_string($db,$_POST['password']);
    $password2=mysqli_real_escape_string($db,$_POST['password2']);  
	$nom=mysqli_real_escape_string($db,$_POST['nom']);
	$prenom=mysqli_real_escape_string($db,$_POST['prenom']);

     if($password==$password2)
     {           //Create User
            $password=md5($password); //hash password before storing for security purposes
            $sql="INSERT INTO adherent(MotDePass, username, AdPrenom,AdNom,AdMail) VALUES('$password','$username','$prenom', '$nom','$email')";
            mysqli_query($db,$sql);  
            $_SESSION['message']="You are now logged in"; 
            $_SESSION['username']=$username;
            header("location:home.php");  //redirect home page
    }
    else
    {
      $_SESSION['message']="The two password do not match";   
     }
}
?><html>
<head>
	<meta charset="UTF-8">
	<title>connexion</title>
	<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Publisher" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
	<META NAME="Language" CONTENT="fr">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" href="css/style.css" type="text/css">
		<link rel="stylesheet" href="css/style1.css" type="text/css">

	<link rel="stylesheet" href="css/connexion.css" type="text/css">
</head>
<body>
	<div id="page">	
		<div id="header">
			<?php
				if(isset($_SESSION['message']))
				{
					 echo "<div username='error_msg'>".$_SESSION['message']."</div>";
					 unset($_SESSION['message']);
				}
			?>
			
			<?php if(!isset($_SESSION['username'])) { echo "<a class='connexion' href='connexion.php'>Connexion</a>" ;  } 
			else { echo "<a class='connexion' href='deconnexion.php'>Deconnexion</a>"; } ?>  
			<a href="inscription.php" class="contact" >S'inscrire</a>
			
			<a href="index.php" id="logo"><img src="images/logo.jpg" widtht= "250" height = "150"  alt="LOGO"> </a>
			<ul id="navigation">
				<li class="selected">
					<a href="index.php" title="Home"></a>
				</li>
				<li>
					<a href="espace.php">Espace personnel</a>
				</li>
				<li>
					<a href="documentation.php">Documentation</a>
				</li>
				<li>
					<a href="service.php">Service</a>
				</li>
				<li>
					<a href="evenement.php">Evenement</a>
				</li>
				<li class="last-child">
					<a href="contact.php">Contact nous</a>
				</li>                         
			</ul>
		</div>
		<div id="contents">
			<div class="background">
				<div id="centre">
					<header>
						<h1 class ="h1">Contact</h1>
					</header>
				<div id="contact-area">

        <form method="post" action="user_process.php">
            <label for="Name">Name:</label>
            <input type="text" name="name" id="Name" />

            <label for="City">City:</label>
            <input type="text" name="city" id="City" />

            <label for="Email">Email:</label>
            <input type="text" name="email" id="Email" />

            <label for="Message">Message:</label><br />
            <textarea name="message" rows="20" cols="20" id="Message"></textarea>

            <input type="submit" name="submit" value="Submit" class="submit-button" />
        </form>

        <div style="clear: both;"></div>
    </div>
			</div>
		</div>
	</div>
</body>
</html>