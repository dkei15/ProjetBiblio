
<html>
<head>
	<meta charset="UTF-8">
	<title>Gestion du bibliothéque</title>
	<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Publisher" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
	<META NAME="Language" CONTENT="fr">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" href="css/style.css" type="text/css">
	
</head>

<body>

<?php
	session_start();
	session_destroy();  
 	
	header ('location:connexion-admin.php');  
?> 
</body>
</html>