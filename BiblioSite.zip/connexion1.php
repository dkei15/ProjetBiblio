<?php session_start() ?>
<html>
<head>
	<meta charset="UTF-8">
	<title>Gestion du bibliothéque</title>
	<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Publisher" CONTENT="Khadija MOUSTAINE"> 
	<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
	<META NAME="Language" CONTENT="fr">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" href="css/style.css" type="text/css">
	
</head>
<body>
	<div id="page">	
		<div id="header">
			
			<?php if(!isset($_SESSION['id'])) { echo "<a class='connexion' href='connexion.php'>Connexion</a>" ;  } 
			else { echo "<a class='connexion' href='deconnexion.php'>Deconnexion</a>"; } ?>  
			<a href="sinscrire.php" class="contact" >S'inscrire</a>
			
			<a href="index.php" id="logo"><img src="images/logo.jpg" widtht= "250" height = "150"  alt="LOGO"> </a>
			<ul id="navigation">
				<li class="selected">
					<a href="index.php" title="Home"></a>
				</li>
				<li>
					<a href="about.html">Espace personnel</a>
				</li>
				<li>
					<a href="product.html">Documentation</a>
				</li>
				<li>
					<a href="solutions.html">Service</a>
				</li>
				<li>
					<a href="news.html">Evenement</a>
				</li>
				<li class="last-child">
					<a href="contact.html">Contact nous</a>
				</li>
			</ul>
		</div>
		<div id="contents">
			<div class="background">
				<div id="centre">
			<header>
				<div id="header">
					<h1 class ="h1">Service d'authentification</h1>
				</div>
			</header>
			<div id="contain">
				<div id="connexion">
					<form method="post" action="cnx.php">
						<section class="row">
							<label for="username">  Indentifiant  </label>
							<input name="id_pers" id="username" type="text" autocomplete="off" size ="25" value="" required />
						</section>
						<section class="row">
							<label for="password">Mot de passe</label>
							<input name="mdp" id="password" type="password" autocomplete="off" size ="25" value=""  required />
						</section>
						<section class="row-btn">
							<input class ="btn-submit" name="submit" type="submit" value="Se connecter"/>
						</section>
				</div>
				<div id="inscription">
					<p>
						<a href ="inscription.php">vous êtes pas inscrit?</a>
					</p>
				</div>
			</div>
			</div>
		</div>
</body>
</html>