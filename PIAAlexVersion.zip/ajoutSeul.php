<?php
session_start();

//connect to database

	$db=mysqli_connect("localhost","root","","biblio");
  if(isset($_GET['contat_btn'])){
		if (empty($_GET['ISBN']) || empty($_GET['TitreOeuvre']) || empty($_GET['typeOeuvre']|| empty($_GET['nomAuteur']) || empty($_GET['dateParu']) || empty($_GET['prixAchat']) || empty($_GET['domaine']))){
			echo '<script>alert(\'Veuillez remplir tous les champs\')</script>';
		}
		else{
			$isbn =  mysqli_real_escape_string($db,$_GET['ISBN']);
			$titreoeuvre =  mysqli_real_escape_string($db,$_GET['TitreOeuvre']);
			$typeoeuvre =  mysqli_real_escape_string($db,$_GET['typeOeuvre']);
			$nomauteur = mysqli_real_escape_string($db,$_GET['nomAuteur']);
			$numExmp = mysqli_real_escape_string($db,$_GET['NumExmp']);
			$listeMotClefs = explode(",",mysqli_real_escape_string($db,$_GET['motClefs']));
			//RAJOUTER LA DATE, PRIX DOMAINE OEUVRE EDITEUR MOTS  CLEFS

			$resultat1 = "SELECT IdAuteur FROM auteur WHERE nomAuteur='".$nomauteur."'";
			$result = mysqli_query($db,$resultat1);
			echo "".$resultat1."";

			$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
			$idauteur = $row['IdAuteur'];


			if(mysqli_num_rows($result)==0){
				$resultat = "INSERT INTO auteur(nomAuteur) VALUES('".$nomauteur."')";
				mysqli_query($db,$resultat);
				$resultat1 = "SELECT IdAuteur FROM auteur WHERE nomAuteur='".$nomauteur."'";
				$result = mysqli_query($db,$resultat1);
				$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
				$idauteur = $row['IdAuteur'];
			}else{
			}
			echo "".$idauteur."";


				$resultat = "INSERT INTO oeuvre(cote,titre,TypeOeuvre,IdAuteur) VALUES (".$isbn.",'".$titreoeuvre."','".$typeoeuvre."',".$idauteur.")" ;
				$resultat1=mysqli_query($db,$resultat);
				echo "".$resultat."";
				echo '<p>Oeuvre et Auteur ajouté avec succès</p>';

				for($j=0;$j<count($listeMotClefs);$j++){
					$resultat2 = "SELECT Id_Mot FROM mot_clefs WHERE  nom='".$listeMotClefs[$j]."'" ;
					$result=mysqli_query($db,$resultat2);
          $length=mysqli_num_rows($result);
					if($length==0){
					$resultat = "INSERT INTO mot_clefs(nom) VALUES ('".$listeMotClefs[$j]."')" ;// AJOUT DU MOT CLEFS
					mysqli_query($db,$resultat);

					$resultat1 = "SELECT Id_Mot FROM mot_clefs WHERE  nom='".$listeMotClefs[$j]."'" ;//RECUPERATION DE L'ID DU MOT_CLEFS
					$result=mysqli_query($db,$resultat1);

					}else{
						$resultat1 = "SELECT Id_Mot FROM mot_clefs WHERE  nom='".$listeMotClefs[$j]."'" ;//RECUPERATION DE L'ID DU MOT_CLEFS
						$result=mysqli_query($db,$resultat1);
					}

					$identifiantMot=mysqli_fetch_array($result, MYSQLI_ASSOC);
					$request = "INSERT INTO appartient(cote,Id_Mot) VALUES (".$isbn.",".$identifiantMot['Id_Mot'].")"; //AJOUT DU MOT CLEFS DANS LA TABLE APPARTIENT
					mysqli_query($db,$request);
					echo '<p>Oeuvre et Auteur ajouté avec succès</p>';

				}
				for($i=0;$i<$numExmp;$i++){
					$resultat2 = 'INSERT INTO exemplaire(cote,Prolongement,EtatExmp,IdEdit,IdRa) VALUES ('.$isbn.',0,0,452,2351)' ;
					mysqli_query($db,$resultat2);
				}
				for($i=0;$i<count($_GET);$i++){
					unset($_GET[$i]);
				}
        echo 'Oeuvre ajoutée avec succès';

	}
}


?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Ajout ou Supprimer</title>
		<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE">
		<META NAME="Publisher" CONTENT="Khadija MOUSTAINE">
		<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
		<META NAME="Language" CONTENT="fr">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="css/style.css" type="text/css">
		<link rel="stylesheet" href="css/connexion.css" type="text/css">

	</head>

	<body>
		<div id="page">
			<div id="header">
				<a href="index.php" id="logo"><img src="images/logo.jpg" width= "250" height = "150"  alt="LOGO"></a>

				<ul id="navigation">
				<li class="selected">
					<a href="index.php" title="Home"></a>
				</li>
				<li>
					<a href="desinscrire.php">Desinscription</a>
				</li>
				<li>
					<a href="ajoutSuppr.php">Ouvress</a>
				</li>
				<li>
					<a href="commande-admin.php">Commande</a>
				</li>
				<li>
					<a href="evenement-admin.php">Evenement</a>
				</li>
				<li>
					<a href="emprunt.php">Emprunt</a>
				</li>
			</ul>
			</div>
			<div id="contents">
				<div class="background">
					<div id="centre">
					<?php
				if(!isset($_SESSION['adminame'])) { echo "" ;  }// A MODIFEIR PAR ADMINAME
				else { echo "<a class='connexion' href='deconnexion.php'>Deconnexion</a>"; }
				?>
						<header>
							<h1 class ="h1">Gestion des oeuvres</h1>


						</header>
						<?php
						if(isset ($_SESSION['adminame'])){ // A MODIFEIR PAR ADMINAME

						echo'	<div id="ajouteOeuvre" align="center">
								<form method="get" action="ajoutSeul.php" >
									<fieldset >
										<table>
											<legend> Ajouter une oeuvre</legend>

											<tr>
													<td width = "150px" class="text"><b>ISBN :</b> </td>
													<td><input type="text" name="ISBN" required=on autocomplete="off"  class="textInput"></td>
											</tr>
											 <tr>
												<td width = "150px" class="text" ><b>Titre de loeuvre :</b> </td>
												<td><input type="text" name="TitreOeuvre" required=on autocomplete="off" class="textInput" ></td>
											</tr>
											<tr>
												<td width = "150px" class="text"><b>Type de loeuvre:</b> </td>
												<td>
													<select name="typeOeuvre" class="textInput">
														<option value="Vide"></<option>
														<option value="Magazine">Magazine</<option>
														<option value="DVD">DVD</<option>
														<option value="Livre">Livre</<option>
														<option value="Periode">Périodique</<option>
														<option value="Partitions">Partitions</<option>
													</select>
											</tr>

												<tr>
												   <td width = "150px" class="text" ><b>Nombre Auteur</b></td>
												   <td><input type="text" name="nomAuteur"required=on class="textInput"></td>
												   <!--<td><input type="text" id="auteur"  name="auteur" value=""></td>-->
												   <!--<td><a href="#"  id="filldetails" onclick="addFields()">Ajouter un auteur</a></td>-->
												</tr>
											    <!--<tr>
													<td width = "150px" class="text"><b>Noms Auteur </b></td>
													<td id="container"></td>
												</tr>-->
											<tr>
												<td width = "150px" class="text"><b>Date de parution:</b></b></td>
												<td><input type="date" name="dateParu"  class="textInput" required=on value="1989-12-22"></td>
											</tr>
											<tr>
												<td width = "150px" class="text"><b>Prix dachat:</b></b></td>
												<td><input type="number" name="prixAchat" required=on class="textInput"></td>
											</tr>
											<tr>
												<td width = "150px" class="text"><b>Domaine:</b></b></td>
												<td>
													<select name="domaine" required=on class="textInput">
														<option value="Vide"></<option>
														<option value="Rom">Roman</<option>
														<option value="Socio">Sociologie</<option>
														<option value="Art">Art</<option>
														<option value="Sciences">Sciences</<option>
														<option value="Culture">Culture</<option>
													</select>
												</td>
											</tr>
											<tr>
											 <td width = "150px" class="text"><b>Nombre d\'exemplaire:</b></b></td>
											 <td>
											 <select name="NumExmp"required=on class="textInput">
												 <option value="1">1</<option>
												 <option value="2">2</<option>
												 <option value="3">3</<option>
												 <option value="4">4</<option>
												 <option value="5">5</<option>
												 <option value="6">6</<option>
												 <option value="7">7</<option>
											 </select>
										 </td>
										 </tr>
										 <tr>
											 <td width = "150px" class="text"><b>Mot clefs:</b></b></td>
											 <td><input type="text" name="motClefs" required=on class="textInput"></td>
										 </tr>
										</table>
									</fieldset>
									</br>
									<input  type="submit" name="contat_btn"  class="login" align="center" value="Ajouter"/>
									<input type="reset" value="Annuler" class="login" />
									</br></br>
								</form>
					</div>';}


				?>
				</div>

				<?php if(!isset($_SESSION['adminame'])){ // A MODIFEIR PAR ADMINAME
					echo "<div id='connexion' align='center'>
								<form method='post' action='connexion-admin.php'>
									<fieldset>
										<table>
											<legend>Informations Personnelles</legend>
											<tr>
												<td width = '150px' class='text' ><b>Indentifiant :</b></td>
												<td><input type='text' name='username' class='textInput' width = '150px'></td>
											</tr>
											<tr>
												<td width = '150px' class='text' ><b>Mot de passe :</b></td>
												<td><input type='password' name='password' class='textInput' width = '150px'></td>
											</tr>
										</table>
									</fieldset>
									</br>
									<input  type='submit' name='admin_btn'  class='login' align='center' value='Se connecter'/>
									<input type='reset' value='Annuler' class='login' />
									</br></br>
								</form>
				</div>";} ?>
			</div>
		</div>
	</body>
</html>
