<?php
session_start();

//connect to database

	$db=mysqli_connect("localhost","root","","biblio");


?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Ajout ou Supprimer</title>
		<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE">
		<META NAME="Publisher" CONTENT="Khadija MOUSTAINE">
		<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
		<META NAME="Language" CONTENT="fr">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="css/style.css" type="text/css">
		<link rel="stylesheet" href="css/connexion.css" type="text/css">
		<link href="calendar/calendar.css" rel="stylesheet" type="text/css" />
		<script language="javascript" src="calendar/calendar.js"></script>

	</head>

	<body>
		<div id="page">
			<div id="header">
			<?php
				if(!isset($_SESSION['adminame'])) { echo "" ;  }
				else { echo "<a class='deconnexion-index' href='deconnexion.php'>Deconnexion</a>"; }
				?>
				<a href="index.php" id="logo"><img src="images/logo.jpg" width= "200" height = "150"  alt="LOGO"></a>

				<ul id="navigation">
				<li class="selected">
					<a href="index.php" title="Home"></a>
				</li>
				<li>
					<a href="desinscrire.php">Desinscription</a>
				</li>
				<li>
					<a href="ajoutSuppr.php">Oeuvres</a>
				</li>
				<li>
					<a href="commande-admin.php">Commande</a>
				</li>
				<li>
					<a href="evenement.php">Evenement</a>
				</li>
				<li>
					<a href="emprunt.php">Emprunt</a>
				</li>
			</ul>
			</div>
			<div id="contents">
				<div class="background">
					<div id="centre">

						<header>
							<h1 class ="h1">Gestion des oeuvres</h1>


						</header>
						<?php
						if(isset ($_SESSION['adminame'])){

			echo'
					<div id="ajouteOeuvre" align="center">
					<a href="ajoutSeul.php"> <input type="button" value="Ajouter"> </a>
					</div>




					<div  align="center">
					<a href="SupprSeul.php"> <input type="button" value="Supprimer"> </a>
					</div>';
						}

				?>
				</div>

				<?php if(!isset($_SESSION['adminame'])){
					echo "<div id='connexion' align='center'>
								<form method='post' action='connexion-admin.php'>
									<fieldset>
										<table>
											<legend>Informations Personnelles</legend>
											<tr>
												<td width = '150px' class='text' ><b>Indentifiant :</b></td>
												<td><input type='text' name='username' class='textInput' width = '150px'></td>
											</tr>
											<tr>
												<td width = '150px' class='text' ><b>Mot de passe :</b></td>
												<td><input type='password' name='password' class='textInput' width = '150px'></td>
											</tr>
										</table>
									</fieldset>
									</br>
									<input  type='submit' name='admin_btn'  class='login' align='center' value='Se connecter'/>
									<input type='reset' value='Annuler' class='login' />
									</br></br>
								</form>
				</div>";} ?>
			</div>
		</div>
	</body>
</html>
