<?php
session_start();
//connect to database
$db=mysqli_connect("localhost","root","","biblio");
if(isset($_POST['admin_btn']))
{
    $adminame=mysqli_real_escape_string($db,$_POST['adminame']);
    $password=mysqli_real_escape_string($db,$_POST['password']);
    $passwordCrypt = md5($password);
    $sql="SELECT adminame, MotDePass,AdmPrenom,AdmNom,AdmMail FROM admin WHERE adminame = '".$adminame."' AND MotDePass = '".$password."'";
	$result = mysqli_query($db,$sql);
	$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
	if($adminame != "" && $password != ""){

			if(mysqli_num_rows($result)> 0)
			{
				$_SESSION['message']="Vous êtes maintenant connecté";
				$_SESSION['adminame']= $row['adminame'];
				$_SESSION['nom'] = $row['AdmNom'];
				$_SESSION['prenom'] = $row['AdmPrenom'];
				$_SESSION['mail'] = $row['AdmMail'];


				header("location:desinscrire.php");
			}
		   else
		   {
						$_SESSION['message']="Nom d'utilisateur ou mot de passe est incorrect ";
			}
	}else{
		$_SESSION['message']="Veuillez remplir les 2 champs! ";
	}
}
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>connexion</title>
		<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE">
		<META NAME="Publisher" CONTENT="Khadija MOUSTAINE">
		<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
		<META NAME="Language" CONTENT="fr">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="css/style.css" type="text/css">
		<link rel="stylesheet" href="css/connexion.css" type="text/css">

	</head>
	<body>
		<div id="page">
			<div id="header">

				<a href="index.php" id="logo"><img src="images/logo.jpg" width= "200" height = "150"  alt="LOGO"> </a>

				<ul id="navigation">
					<li class="selected">
						<a href="index.php" title="Home"></a>
					</li>

				</ul>
			</div>

			<div id="contents">
				<div class="background">
					<div id="centre">
						<header>
							<h1 class ="h1">Espace Admin</h1>
							<?php
								if(isset($_SESSION['message']))
								{
									 echo "<div adminame='error_msg'>".$_SESSION['message']."</div>";
									 unset($_SESSION['message']);
								}
							?>


						</header>
						<div id="connexion" align="center">
							<form method="post" action="connexion-admin.php">
								<fieldset>
									<table>
										<legend>Identifiez-vous pour poursuivre</legend>
										<tr>
											<td width = "150px" class="text" ><b>Indentifiant :</b></td>
											<td><input type="text" name="adminame" class="textInput" width = "150px"></td>
										</tr>
										<tr>
											<td width = "150px" class="text" ><b>Mot de passe :</b></td>
											<td><input type="password" name="password" class="textInput" width = "150px"></td>
										</tr>
									</table>
								</fieldset>
								</br>
								<input  type="submit" name="admin_btn"  class="login" align="center" value="Se connecter"/>
								<input type="reset" value="Annuler" class="login" />
								</br></br>
							</form>
						</div>
					</div>
				</div>



			</div>
			<div id="footer">

			<p>Site crée par Khadija MOUSTAINE, Alex TAYLOR, Anaud BROSSE </p>
		</div>
		</div>
	</body>
</html>
