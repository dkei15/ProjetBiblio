<?php
session_start();

//connect to database
$db=mysqli_connect("localhost","root","","biblio");
	if(isset($_POST['btn_rech'])){
		$rech = mysqli_real_escape_string($db,$_POST['resAdherent']);
		$sql = "SELECT username FROM adherent WHERE username = '$rech'";
		$result = mysqli_query($db,$sql);
		$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
		if(mysqli_num_rows($result) > 0){
			$_SESSION['recherche'] =  $row['username'];
		}else{
			$_SESSION['message'] = 'cet utilisateur n\'existe pas ';
		}
	}

	if(isset($_POST['btn_des'])){
		$rech = $_SESSION['recherche'];
		$sql = "DELETE FROM adherent WHERE username = '$rech'";
		mysqli_query($db,$sql);
		$_SESSION['message'] = 'cet adhérent a été supprimé avec succès ';
		unset($_SESSION['recherche']);
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>connexion</title>
	<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE">
	<META NAME="Publisher" CONTENT="Khadija MOUSTAINE">
	<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
	<META NAME="Language" CONTENT="fr">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/connexion.css" type="text/css">
</head>
<body>
	<div id="page">
		<div id="header">
			<?php if(!isset($_SESSION['username'])) { echo "<a class='connexion' href='connexion.php'>Connexion</a>" ;  }
			else { echo "<a class='deconnexion' href='deconnexion.php'>Deconnexion</a>"; } ?>


			<a href="index.php" id="logo"><img src="images/logo.jpg" widtht= "250" height = "150"  alt="LOGO"> </a>
			<ul id="navigation">
			<li class="selected">
				<a href="index.php" title="Home"></a>
			</li>
			<li>
				<a href="desinscrire.php">Desinscription</a>
			</li>
			<li>
				<a href="ajoutSuppr.php">Oeuvres</a>
			</li>
			<li>
				<a href="commande-admin.php">Commande</a>
			</li>
			<li>
				<a href="ajoutEvenement.php">Evenement</a>
			</li>
			<li>
				<a href="emprunt.php">Emprunt</a>
			</li>
		</ul>
		</div>
		<div id="contents">
			<div class="background">
				<div id="centre">
					<header>
						<h1 class ="h1">Désincrire Adhérent</h1>
					</header>
					<form method="post" action="desinscrire.php">
						<div>
							<input type="text" class="login" name ="resAdherent"> </input>
							<input type="submit" class="login" name="btn_rech" value="Recherche"> </input>
						</div>


						<?php
							if(isset($_SESSION['recherche'])){
							echo '<div>
									<label>Username trouvé :  '.$_SESSION['recherche'].'</label>
									<input type="submit" class="login" name="btn_des" value="Désinscrire"> </input>
								 </div>';
						    }
						 ?>
						 <?php
								if(isset($_SESSION['message']))
								{
									 echo "<div username='error_msg'>".$_SESSION['message']."</div>";
									 unset($_SESSION['message']);
								}
							?>
					</form>
				</div>
			</div>
		</div>
</body>
</html>
