<?php
	session_start();
	if (!isset($_SESSION['login'])) {
	header ('index.php');
	exit();
	}
	include("config.php")
	?>
 
<?php
mysql_connect($host, $user, $password); 
	mysql_select_db ($database) or die ("connection imposible");
 
if ($_POST['envoi']=="Modifier"){
	echo "modification";
	?>
	<html>
<form action="modifObjet.php" method="post"> 
		Nom : <input type="text" name="nom" value="<?php if (isset($_POST['nom'])) echo htmlentities(trim($_POST['nom'])); ?>"><br/>
		Catégorie : <input type="text" name="categorie" value="<?php if (isset($_POST['categorie'])) echo htmlentities(trim($_POST['categorie'])); ?>"><br/>
		Vignette : <input type="text" name="vignette" value="<?php if (isset($_POST['vignette'])) echo htmlentities(trim($_POST['vignette'])); ?>"><br/>
		Lien : <input type="text" name="lien" value="<?php if (isset($_POST['lien'])) echo htmlentities(trim($_POST['lien'])); ?>"><br/>
</form>
<?php 
	echo "<form action='modifObjet.php' method='POST'> <input name='envoi' type='submit' value='Inserer'>";
?>
</html>
	<?php	
	$vobjet=$_POST['Objetsel'];
	echo "$vobjet";
$rq="UPDATE Objet SET nom='$nom' ,categorie='$cat',vignette='$vignette', lien='$lien' WHERE id='$id'";
	mysql_query($rq) or die ("planté!!!");	
}
if ($_POST['envoi']=="Supprimer"){	
	echo "supression";
	$vobjet=$_POST['Objetsel'];
	echo "$vobjet";
	$rq="DELETE FROM Objet WHERE nom='$vobjet'";
	mysql_query($rq);
	echo "Votre ligne a été supprimer";
}	
 
?>