<?php
session_start();

//connect to database

include("connectToBase.php");

	if(isset($_POST['command_btn'])){
		if(empty($_POST['ISBN']) || empty($_POST['TitreOeuvre']) || empty($_POST['commentaire'])){
				$_SESSION['message'] = 'remplissez tous les champs SVP';
		}else{

				$isbn = mysqli_real_escape_string($db,$_POST['ISBN']);
				$titreOeuvre = mysqli_real_escape_string($db,$_POST['TitreOeuvre']);
				$commentaire = mysqli_real_escape_string($db,$_POST['commentaire']);
				$idAdherent = $_SESSION['IdAdherent'];
				$sql = "INSERT INTO commande (dateCommnde,titreOeuvre,Commentaire,cote,idAdherent) VALUES(now(),'$titreOeuvre','$commentaire','$isbn','$idAdherent')";
				mysqli_query($db,$sql);
				$_SESSION['message'] = 'votre commande a Ã©tÃ© enregistÃ©e avec ssuccÃ¨s';
			}
	}

?>
<!DOCTYPE html>
<html>
		<head>
		<meta charset="UTF-8">
		<title>Inscription</title>
		<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE">
		<META NAME="Publisher" CONTENT="Khadija MOUSTAINE">
		<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
		<META NAME="Language" CONTENT="fr">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="css/style.css" type="text/css">
		<link rel="stylesheet" href="css/connexion.css" type="text/css">
		<link href="calendar/calendar.css" rel="stylesheet" type="text/css" />
		<script language="javascript" src="calendar/calendar.js"></script>
	</head>

	<body>
		<div id="page">
			<div id="header">
				<?php
					if(!isset($_SESSION['username']))
					{
						echo "<a class='connexion-index' href='connexion.php'>Connexion</a>" ;
					}
					else
					{
						echo "<a class='connexion' href='deconnexion.php'>Deconnexion</a>";
					}
				?>

				<a href="inscription.php" class="contact" >S'inscrire</a>
				<a href="index.php" id="logo"><img src="images/logo.jpg" width= "200" height = "150"  alt="LOGO"></a>

				<ul id="navigation">
					<li class="selected">
						<a href="index.php" title="Home"></a>
					</li>
					<li>
						<a href="espace.php">Espace personnel</a>
					</li>
					<li>
						<a href="documentation.php">Documentation</a>
					</li>
					<li>
						<a href="service.php">Service</a>
					</li>
					<li>
						<a href="evenement.php">Evenement</a>
					</li>
					<li class="last-child">
						<a href="contact.php">Contact nous</a>
					</li>
				</ul>
			</div>
			<div id="contents">
				<div class="background">
					<div id="centre">

						<header>
							<h1 class ="h1">Commande</h1>


						</header>

						<?php
						if(isset ($_SESSION['username'])){

						echo'	<div id="ajouteOeuvre" align="center">
								<form method="post" action="commande.php" >
									<fieldset >
										<table>
											<legend> Ajouter un commande</legend>

											<tr>
													<td width = "150px" height="40px" class="text"><b>ISBN :</b> </td>
													<td width = "150px" height="40px" ><input type="text" name="ISBN" autocomplete="off"  class="textInput"></td>
											</tr>
											 <tr>
												<td width = "150px" height="40px"  class="text" ><b>Titre de loeuvre :</b> </td>
												<td width = "150px" height="40px" ><input type="text" name="TitreOeuvre" autocomplete="off" class="textInput" ></td>
											</tr>
											<tr>
												<td width = "150px" height="40px"  class="text"><b>Commentaire:</b></b></td>
												<td width = "150px" height="40px"  class="text">
													<textarea rows="4" cols="35" name="commentaire" placeholder="Tapez un commentatire...."  class="textInput"></textarea>
											  </td>
											</tr>



										</table>
									</fieldset>
									</br>
									<input  type="submit" name="command_btn"  class="login" align="center" value="Envoyer"/>
									<input type="reset" value="Annuler" class="login" />
									</br></br>
								</form>
					</div>';
				   }
				?>
				</div>

						<?php
							if(!isset($_SESSION['username']))
							{
								echo "<div id='connexion' align='center'>
									<form method='post' action='connexion.php'>
										<fieldset>
											<table>
												<legend>Informations Personnelles</legend>
												<tr>
													<td width = '150px' height='40px' class='text' ><b>Indentifiant :</b></td>
													<td><input type='text' name='username' class='textInput' width = '150px'></td>
												</tr>
												<tr>
													<td width = '150px' height='40px' class='text' ><b>Mot de passe :</b></td>
													<td><input type='password' name='password' class='textInput' width = '150px'></td>
												</tr>
											</table>
										</fieldset>
										</br>
										<input  type='submit' name='connexion_btn'  class='login' align='center' value='Se connecter'/>
										<input type='reset' value='Annuler' class='login' />
										</br>
										</br>
									</form>
								</div>";}
							?>
							<?php
								if(isset($_SESSION['message']))
								{
									echo "<div username='error_msg'>".$_SESSION['message']."</div>";
									unset($_SESSION['message']);
								}
							?>
			</div>
		</div>
	</body>
</html>
