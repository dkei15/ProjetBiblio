<?php
session_start();

//connect to database

	$db=mysqli_connect("localhost","root","","biblio");




?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Ajout ou Supprimer</title>
		<META NAME="Author" LANG="fr" CONTENT="Khadija MOUSTAINE">
		<META NAME="Publisher" CONTENT="Khadija MOUSTAINE">
		<META NAME="Reply-to" CONTENT="moustaine-khadija@hotmail.fr (Khadija MOUSTAINE)">
		<META NAME="Language" CONTENT="fr">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="css/style.css" type="text/css">
		<link rel="stylesheet" href="css/connexion.css" type="text/css">

	</head>

	<body>
		<div id="page">
			<div id="header">
				<a href="index.php" id="logo"><img src="images/logo.jpg" width= "250" height = "150"  alt="LOGO"></a>

				<ul id="navigation">
				<li class="selected">
					<a href="index.php" title="Home"></a>
				</li>
				<li>
					<a href="desinscrire.php">Desinscription</a>
				</li>
				<li>
					<a href="ajoutSuppr.php">Ouvress</a>
				</li>
				<li>
					<a href="commande-admin.php">Commande</a>
				</li>
				<li>
					<a href="evenement-admin.php">Evenement</a>
				</li>
				<li>
					<a href="emprunt.php">Emprunt</a>
				</li>
			</ul>
			</div>
			<div id="contents">
				<div class="background">
					<div id="centre">
					<?php
				if(!isset($_SESSION['adminame'])) { echo "" ;  }// A MODIFEIR PAR ADMINAME
				else { echo "<a class='connexion' href='deconnexion.php'>Deconnexion</a>"; }
				?>
						<header>
							<h1 class ="h1">Emprunt/Retour de livre</h1>
						</header>
						<?php

						if(isset ($_SESSION['adminame'])){ // A MODIFEIR PAR ADMINAME
							if(isset($_GET['finish'])){
								header('Location: emprunt.php');
								exit(0);
							}
						echo'	<div id="ajouteOeuvre" align="center">';
						if(isset($_GET['emprunt_action'])){
							// OBtenir le numero de l'eouvre
							echo "Je suis là";
							$identif= mysqli_real_escape_string($db,$_GET['Identif']);
							$numExmp =  mysqli_real_escape_string($db,$_GET['NumExmp']);
							$resultat1 ="SELECT cote FROM exemplaire WHERE NumExmp=".$numExmp."";
							$result=mysqli_query($db,$resultat1);
							$tab=mysqli_fetch_array($result, MYSQLI_ASSOC);
							echo "Je suis là 2";

							$isbn =  $tab['cote'];
							$resultat1 ="DELETE  FROM reserve  WHERE IdAdherent=".$identif." AND cote=".$isbn." ";
							$result=mysqli_query($db,$resultat1);


							$resultat1 ="UPDATE exemplaire SET EtatExmp=1, IdAdherent=".$identif.", DateRetour=DATE_ADD(Now(), INTERVAL 1 MONTH) WHERE NumExmp=".$numExmp."";

							if(mysqli_query($db,$resultat1)==FALSE){
								echo "Une erreur s'est produite lors de l'emprunt";
							}else{
							}
							$resultat1 ="SELECT * FROM reserve  WHERE IdAdherent=".$identif."  AND cote =".$isbn." ";
							$result=mysqli_query($db,$resultat1);
							$rows=mysqli_num_rows($result);

							if($rows>0){

								}
							unset($_GET['NumExmp']);
							unset($_GET['emprunt_action']);

				}else if( isset($_GET['retour_action']) ) {
					// OBtenir le numero de l'eouvre
					$identif= mysqli_real_escape_string($db,$_GET['Identif']);
					$numExmp =  mysqli_real_escape_string($db,$_GET['NumExmp']);
					$resultat1 ="SELECT cote FROM exemplaire WHERE NumExmp=".$numExmp."";
					$result=mysqli_query($db,$resultat1);
					$tab=mysqli_fetch_array($result, MYSQLI_ASSOC);

					$isbn =  $tab['cote'];

					$resultat1 ="SELECT * FROM reserve WHERE cote=".$isbn."  ";
					$result=mysqli_query($db,$resultat1);
					$rows=mysqli_num_rows($result);

					if($rows>0){// ON regarde dans reservation et OUI il y a une reservation sur l'oeuvre
						$resultat1 ="SELECT * FROM reserve WHERE DateReservation = (SELECT MIN(DateReservation) as DateReservation1 FROM reserve WHERE DateReservation IS NOT NULL AND cote=".$isbn.") ";
						$result=mysqli_query($db,$resultat1);
						$tab=mysqli_fetch_array($result, MYSQLI_ASSOC);
						$identif2=$tab['IdAdherent'];
						$resultat1 ="UPDATE exemplaire SET Prolongement=0, EtatExmp=1, IdAdherent=".$identif2.", DateRetour=NULL WHERE NumExmp=".$numExmp."  ";
					  mysqli_query($db,$resultat1);

						$resultat1 ="UPDATE reserve SET DateReservation=NULL WHERE IdAdherent=".$identif2." AND cote=".$isbn." ";
					  mysqli_query($db,$resultat1);
					
						}

					else{ //Sinon cela veut dire qu'il y a rien et donc YOLO on fait une requête simple
						$resultat1 ="UPDATE exemplaire SET Prolongement=0, EtatExmp=0, IdAdherent=NULL , DateRetour=NULL WHERE NumExmp=".$numExmp."";
						mysqli_query($db,$resultat1);
					}
				}

							echo'	<form method="get" action="emprunt.php" >
									<fieldset >
										<table>

										<tr>
										 <td width = "200px" class="text" ><b>Numero d\'adherent :</b> </td>
										 <td><input type="text" name="Identif"  autocomplete="off" class="textInput" ></td>
									 </tr>
											 <tr>
												<td width = "200px" class="text" ><b>Numero d\'exemplaire :</b> </td>
												<td><input type="text" name="NumExmp"  autocomplete="off" class="textInput" ></td>
											</tr>
                    </table>
									</fieldset>
									</br>
									<input  type="submit" name="emprunt_action"  class="login" align="center" value="Emprunt"/>
									<input  type="submit" name="retour_action"  class="login" align="center" value="Retour"/>
									<input  type="submit" name="finish"  class="login" align="center" value="Terminer"/>

									<input type="reset" value="Annuler" class="login" />
									</br></br>
								</form>

					</div>';



}


				?>
				</div>

				<?php if(!isset($_SESSION['adminame'])){ // A MODIFEIR PAR ADMINAME
					echo "<div id='connexion' align='center'>
								<form method='post' action='connexion-admin.php'>
									<fieldset>
										<table>
											<legend>Informations Personnelles</legend>
											<tr>
												<td width = '150px' class='text' ><b>Indentifiant :</b></td>
												<td><input type='text' name='username' class='textInput' width = '150px'></td>
											</tr>
											<tr>
												<td width = '150px' class='text' ><b>Mot de passe :</b></td>
												<td><input type='password' name='password' class='textInput' width = '150px'></td>
											</tr>
										</table>
									</fieldset>
									</br>
									<input  type='submit' name='admin_btn'  class='login' align='center' value='Se connecter'/>
									<input type='reset' value='Annuler' class='login' />
									</br></br>
								</form>
				</div>";} ?>
			</div>
		</div>
	</body>
</html>
